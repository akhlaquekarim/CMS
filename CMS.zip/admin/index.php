<?php
include('login.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
header("location: cms.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login Form </title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<style>
.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
<body>
<div style="text-align:center; margin-left:-60px;">
<a href="../index.php"><button class="button" >HOME</button></a>
</div>
<div id="main" >

<div id="login">
<h2>CMS Admin Login </h2>
<form action="index.php" method="post" ><br/>
<label>UserName :</label>
<input id="name" name="username" placeholder="username" type="text"><br/><br/>
<label>Password :</label>
<input id="password" name="password" placeholder="********" type="password"><br/><br/>
<input name="submit" type="submit" value=" Login ">
<span><?php echo $error; ?></span>
</form>
</div>
</div>
</body>
</html>