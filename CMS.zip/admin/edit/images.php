<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    
    <!-- Title Tag -->
    <title>CMS</title>
<!--


    <!-- <<Mobile Viewport Code>> -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
            
    <!-- <<Attched Stylesheets>> -->
    <link rel="stylesheet" href="../../css/theme.css" type="text/css" />
    <link rel="stylesheet" href="../../css/media.css" type="text/css" />
    <link rel="stylesheet" href="../../css/font-awesome.min.css" type="text/css" />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,600italic,400italic,800,700' rel='stylesheet' type='text/css'>    
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>

	<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
	padding: 10px;
}

img {
    display: block;
    margin: 0 auto;
}

</style>
	
</head>
<body>

<!-- \\ Begin Holder \\ -->
<div class="DesignHolder">
	<!-- \\ Begin Frame \\ -->
	<div class="LayoutFrame">
        <!-- \\ Begin Header \\ -->
		
		<header>
            <div class="Center">
                <div class="site-logo">
                	<h3 style="color:white;">Welcome : <i style="text-transform: capitalize;"><?php echo $login_session; ?></i></h3>
                </div>
               <div id="mobile_sec">
               <div class="mobile"><i class="fa fa-bars"></i><i class="fa fa-times"></i></div>
                <div class="menumobile">
                    <!-- \\ Begin Navigation \\ -->
                    <nav class="Navigation">
                        <ul>
							
                            <li class="active">                                
                                <a href="logout.php">Log Out</a>
                                <span class="menu-item-sm"></span>
                            </li>
                            <li class="">                                
                                <a href="../index.php">Home</a>
                                <span class="menu-item-sm"></span>
                            </li>
                        </ul>
                    </nav>
                    <!-- // End Navigation // -->
				</div>
				</div>
                <div class="clear"></div>
            </div>
        </header>
       <!-- // End Header // -->
		<div class="bgcolor"></div>
        <!-- \\ Begin Banner Section \\ -->
       <div id="Container">
            <!-- \\ Begin About Section \\ -->
			<br/><br/><br/>
       
            <!-- \\ Begin About Section \\ -->
            <div class="About_sec" id="about" style="padding-top:30px;">
                <div class="Center">            	
                              		
                     <div><form enctype="multipart/form-data" action=
"<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="MAX_FILE_SIZE" value="10000000" />
<input name="userfile" type="file" />
<input type="submit" value="Submit" />
</form>

<?php

// check if a file was submitted
if(!isset($_FILES['userfile']))
{
    echo '<p style="color:blue;">Please select a file</p>';
}
else
{
    try {
    $msg= upload();  //this will upload your image
    echo $msg;  //Message showing success or failure.
    }
    catch(Exception $e) {
    echo $e->getMessage();
    echo '<p style="color:#E74C3C;">Sorry, could not upload file</p>';
    }
}

// the upload function

function upload() {
    include "../../connect.php";
    $maxsize = 10000000; //set to approx 10 MB

    //check associated error code
    if($_FILES['userfile']['error']==UPLOAD_ERR_OK) {

        //check whether file is uploaded with HTTP POST
        if(is_uploaded_file($_FILES['userfile']['tmp_name'])) {    

            //checks size of uploaded image on server side
            if( $_FILES['userfile']['size'] < $maxsize) {  
  
               //checks whether uploaded file is of image type
              //if(strpos(mime_content_type($_FILES['userfile']['tmp_name']),"image")===0) {
                 $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if(strpos(finfo_file($finfo, $_FILES['userfile']['tmp_name']),"image")===0) {    

                    // prepare the image for insertion
                    $imgData =addslashes (file_get_contents($_FILES['userfile']['tmp_name']));

                    // put the image in the db...
                    // database connection
                    mysql_connect('localhost', 'root', '') OR DIE (mysql_error());

                    // select the db
                    mysql_select_db ('cms') OR DIE ("Unable to select db".mysql_error());

                    // our sql query
                    $sql = "UPDATE  images
					SET image='".$imgData."'
                    WHERE id=1;";

                    // insert the image
                    mysql_query($sql) or die("Error in Query: " . mysql_error());
                    $msg='<p style="color:green">Image successfully Updated. </p>';
                }
                else
                    $msg='<p style="color:#E74C3C;">Uploaded file is not an image.</p>';
            }
             else {
                // if the file is not less than the maximum allowed, print an error
                $msg='<div>File exceeds the Maximum File limit</div>
                <div>Maximum File limit is '.$maxsize.' bytes</div>
                <div>File '.$_FILES['userfile']['name'].' is '.$_FILES['userfile']['size'].
                ' bytes</div><hr />';
                }
        }
        else
            $msg='<p style="color:#E74C3C;">File not uploaded successfully.</p>';

    }
    else {
        $msg= file_upload_error_message($_FILES['userfile']['error']);
    }
    return $msg;
}

// Function to return error message based on error code

function file_upload_error_message($error_code) {
    switch ($error_code) {
        case UPLOAD_ERR_INI_SIZE:
            return '<p style="color:#E74C3C;">The uploaded file exceeds the upload_max_filesize of 1 MB.</p>';
        case UPLOAD_ERR_FORM_SIZE:
            return '<p style="color:#E74C3C;">The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form</p>';
        case UPLOAD_ERR_PARTIAL:
            return '<p style="color:#E74C3C;">The uploaded file was only partially uploaded</p>';
        case UPLOAD_ERR_NO_FILE:
            return '<p style="color:#E74C3C;">No file was uploaded</p>';
        case UPLOAD_ERR_NO_TMP_DIR:
            return '<p style="color:#E74C3C;">Missing a temporary folder</p>';
        case UPLOAD_ERR_CANT_WRITE:
            return '<p style="color:#E74C3C;">Failed to write file to disk</p>';
        case UPLOAD_ERR_EXTENSION:
            return '<p style="color:#E74C3C;">File upload stopped by extension</p>';
        default:
            return '<p style="color:#E74C3C;">Unknown upload error</p>';
    }
}
?>
<?php
 $connect = mysqli_connect("localhost", "root", "", "cms");
 $query = "SELECT * FROM images WHERE id=1";
 $result = mysqli_query($connect,$query);
 while($row= mysqli_fetch_array($result)){
	 
	 echo'
	 <tr>
	 <td>
	 <img align="middle" height="200" width="300" src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'" />
	 </td>
	 </tr>';
	 
	
 }
 

?>

</body>
</html>