<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    
    <!-- Title Tag -->
    <title>CMS</title>
<!--


    <!-- <<Mobile Viewport Code>> -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
            
    <!-- <<Attched Stylesheets>> -->
    <link rel="stylesheet" href="../../css/theme.css" type="text/css" />
    <link rel="stylesheet" href="../../css/media.css" type="text/css" />
    <link rel="stylesheet" href="../../css/font-awesome.min.css" type="text/css" />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,600italic,400italic,800,700' rel='stylesheet' type='text/css'>    
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>

	<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
	padding: 10px;
}

img {
    display: block;
    margin: 0 auto;
}

input[type=submit] {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 16px 32px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
}

</style>
	
</head>
<body>

<!-- \\ Begin Holder \\ -->
<div class="DesignHolder">
	<!-- \\ Begin Frame \\ -->
	<div class="LayoutFrame">
        <!-- \\ Begin Header \\ -->
		
		<header>
            <div class="Center">
                <div class="site-logo">
                	<h3 style="color:white;">Welcome : <i style="text-transform: capitalize;"><?php echo $login_session; ?></i></h3>
                </div>
               <div id="mobile_sec">
               <div class="mobile"><i class="fa fa-bars"></i><i class="fa fa-times"></i></div>
                <div class="menumobile">
                    <!-- \\ Begin Navigation \\ -->
                    <nav class="Navigation">
                        <ul>
							
                            <li class="">                                
                                <a href="logout.php">Log Out</a>
                                <span class="menu-item-sm"></span>
                            </li>
                            <li class="active">                                
                                <a href="../cms.php">Home</a>
                                <span class="menu-item-sm"></span>
                            </li>
                        </ul>
                    </nav>
                    <!-- // End Navigation // -->
				</div>
				</div>
                <div class="clear"></div>
            </div>
        </header>
       <!-- // End Header // -->
		<div class="bgcolor"></div>
        <!-- \\ Begin Banner Section \\ -->
       <div id="Container">
            <!-- \\ Begin About Section \\ -->
			<br/><br/><br/>
       
            <!-- \\ Begin About Section \\ -->
            <div class="About_sec" id="about" style="padding-top:30px;">
                <div class="Center"> 
<form action="update_intro.php" method="post">
<div id="login">
<textarea style="padding:20px; border:1px solid blue" rows="20" cols="109" id="name" name="username" type="text" >
<?php
include '../../connect.php';
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT intro FROM course";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo $row["intro"];
    }
} else {
    echo "0 results";
}

$conn->close();

?> 
</textarea>
<br/><br/>

<input  id="submit" name="submit" type="submit" value=" Update ">
</div>
</form>
</div>
</body>
</html>

 