<?php 
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    
    <!-- Title Tag -->
    <title>CMS</title>
<!--


    <!-- <<Mobile Viewport Code>> -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
            
    <!-- <<Attched Stylesheets>> -->
    <link rel="stylesheet" href="../../css/theme.css" type="text/css" />
    <link rel="stylesheet" href="../../css/media.css" type="text/css" />
    <link rel="stylesheet" href="../../css/font-awesome.min.css" type="text/css" />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,600italic,400italic,800,700' rel='stylesheet' type='text/css'>    
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>

	<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
	padding: 10px;
}

img {
    display: block;
    margin: 0 auto;
}

</style>
	
</head>
<body>

<!-- \\ Begin Holder \\ -->
<div class="DesignHolder">
	<!-- \\ Begin Frame \\ -->
	<div class="LayoutFrame">
        <!-- \\ Begin Header \\ -->
		
		<header>
            <div class="Center">
                <div class="site-logo">
                	<h3 style="color:white;">Welcome : <i style="text-transform: capitalize;"><?php echo $login_session; ?></i></h3>
                </div>
               <div id="mobile_sec">
               <div class="mobile"><i class="fa fa-bars"></i><i class="fa fa-times"></i></div>
                <div class="menumobile">
                    <!-- \\ Begin Navigation \\ -->
                    <nav class="Navigation">
                        <ul>
							
                            <li class="">                                
                                <a href="logout.php">Log Out</a>
                                <span class="menu-item-sm"></span>
                            </li>
                            <li class="active">                                
                                <a href="../cms.php">Home</a>
                                <span class="menu-item-sm"></span>
                            </li>
                        </ul>
                    </nav>
                    <!-- // End Navigation // -->
				</div>
				</div>
                <div class="clear"></div>
            </div>
        </header>
       <!-- // End Header // -->
		<div class="bgcolor"></div>
        <!-- \\ Begin Banner Section \\ -->
       <div id="Container">
            <!-- \\ Begin About Section \\ -->
			<br/><br/><br/>
       
            <!-- \\ Begin About Section \\ -->
            <div class="About_sec" id="about" style="padding-top:30px;">
                <div class="Center"> 
<?php

include '../../connect.php';
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if (isset($_POST['submit'])) {
if (empty($_POST['username'])) {
$error = "Enter text please";
}
else
{
	// Define $username and $password
$username=$_POST['username'];
$sql = "UPDATE course SET intro= '$username' WHERE id=1";
}
}


if ($conn->query($sql) === TRUE) {
    echo '<h3 style="text-align:center; color:#239B56 ; margin-top:50px;" >Record updated successfully</h3>';
	} else {
    echo '<h3 style="text-align:center; color:#B03A2E    ; margin-top:50px;" >Error in updating Record</h1>' . $conn->error;
}

$conn->close();
?>
</body>
</html>